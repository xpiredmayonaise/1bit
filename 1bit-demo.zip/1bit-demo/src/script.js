/***************
 * UTIL / UI
 ***************/
const ui = {
  showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.style.display = 'block';
    setTimeout(() => t.style.display = 'none', 1800);
  },
  showPage(id) {
    document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
    document.getElementById(id).classList.remove('hidden');
  },
  click() {
    // synthesize a tiny retro "blip" (no external audio needed)
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.type = 'square'; o.frequency.setValueAtTime(880, ctx.currentTime);
    g.gain.setValueAtTime(0.04, ctx.currentTime);
    o.start(); o.stop(ctx.currentTime + 0.05);
  },
  toggleTheme() {
    document.body.classList.toggle('light');
    localStorage.setItem('theme', document.body.classList.contains('light') ? 'light' : 'dark');
  },
  applyTheme() {
    const saved = localStorage.getItem('theme');
    if (saved === 'light') document.body.classList.add('light');
  },
  setNavState(isAuthed) {
    document.getElementById('authBtn').classList.toggle('hidden', isAuthed);
    document.getElementById('logoutBtn').classList.toggle('hidden', !isAuthed);
    document.getElementById('profileBtn').classList.toggle('hidden', !isAuthed);
  }
};

function showPage(id){ ui.showPage(id); } // keep old API for your buttons

/***************
 * AUTH (demo only)
 ***************/
const storage = {
  getUsers() { return JSON.parse(localStorage.getItem('1bit_users') || '{}'); },
  setUsers(obj) { localStorage.setItem('1bit_users', JSON.stringify(obj)); },
  getSession() { return JSON.parse(localStorage.getItem('1bit_session') || 'null'); },
  setSession(u) { localStorage.setItem('1bit_session', JSON.stringify(u)); },
  clearSession() { localStorage.removeItem('1bit_session'); },
  getUploads(username) { return JSON.parse(localStorage.getItem(`1bit_uploads_${username}`) || '[]'); },
  setUploads(username, arr) { localStorage.setItem(`1bit_uploads_${username}`, JSON.stringify(arr)); },
  getAvatar(username) { return localStorage.getItem(`1bit_avatar_${username}`); },
  setAvatar(username, dataUrl) { localStorage.setItem(`1bit_avatar_${username}`, dataUrl); }
};

// silly "hash" for demo uniqueness (NOT secure)
const hash = str => btoa(unescape(encodeURIComponent(str)));

const auth = {
  switchTab(which) {
    const login = document.getElementById('loginForm');
    const signup = document.getElementById('signupForm');
    const tabL = document.getElementById('tabLogin');
    const tabS = document.getElementById('tabSignup');
    const isLogin = which === 'login';
    login.classList.toggle('hidden', !isLogin);
    signup.classList.toggle('hidden', isLogin);
    tabL.classList.toggle('active', isLogin);
    tabS.classList.toggle('active', !isLogin);
  },

  signup(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const username = (fd.get('username') || '').trim();
    const email = (fd.get('email') || '').trim();
    const pass = fd.get('password') || '';
    const confirm = fd.get('confirm') || '';

    if (!/^[a-zA-Z0-9_]{3,16}$/.test(username)) return ui.showToast('Invalid username.');
    if (pass.length < 6) return ui.showToast('Password too short.');
    if (pass !== confirm) return ui.showToast('Passwords do not match.');

    const users = storage.getUsers();
    if (users[username]) return ui.showToast('Username already exists.');

    users[username] = { email, pass: hash(pass), created: Date.now() };
    storage.setUsers(users);
    storage.setSession({ username });
    ui.setNavState(true);
    populate.profile();
    ui.showToast('Account created! Welcome.');
    ui.showPage('profile');
    e.target.reset();
  },

  login(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const username = (fd.get('username') || '').trim();
    const pass = fd.get('password') || '';
    const users = storage.getUsers();
    const user = users[username];

    if (!user || user.pass !== hash(pass)) {
      return ui.showToast('Invalid credentials.');
    }
    storage.setSession({ username });
    ui.setNavState(true);
    populate.profile();
    ui.showToast(`Welcome, ${username}!`);
    ui.showPage('gallery');
    e.target.reset();
    gallery.init(); // ensure grids are filled
  },

  logout() {
    storage.clearSession();
    ui.setNavState(false);
    ui.showToast('Logged out.');
    ui.showPage('home');
  }
};

/***************
 * GALLERY
 ***************/
const gallery = {
  starter: [
    "https://i.imgur.com/NJ9wCzd.png",
    "https://i.imgur.com/3Y1E5gf.png",
    "https://i.imgur.com/Nu1PGe9.png",
    "https://i.imgur.com/uHG8lS1.png",
    "https://i.imgur.com/5jJ3uAh.png",
    "https://i.imgur.com/Gg7c7wJ.png"
  ],
  moreIndex: 0,
  previewDataUrl: null,

  init() {
    const session = storage.getSession();
    const locked = !session;
    document.getElementById('lockedMsg').classList.toggle('hidden', !locked);
    document.getElementById('galleryContent').classList.toggle('hidden', locked);
    if (locked) return;

    // public gallery
    const artGrid = document.getElementById('artGrid');
    if (!artGrid.dataset.filled) {
      this.starter.slice(0, 6).forEach(src => artGrid.appendChild(this.imgEl(src)));
      artGrid.dataset.filled = '1';
    }

    // my uploads
    this.renderMyUploads();
  },

  imgEl(src) {
    const img = document.createElement('img');
    img.src = src;
    img.alt = "Pixel Art";
    return img;
  },

  loadMore() {
    const artGrid = document.getElementById('artGrid');
    for (let i = 0; i < 3; i++) {
      const src = this.starter[(this.moreIndex++) % this.starter.length];
      artGrid.appendChild(this.imgEl(src));
    }
  },

  previewUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    const rd = new FileReader();
    rd.onload = () => {
      this.previewDataUrl = rd.result;
      const img = this.imgEl(rd.result);
      img.classList.add('uploaded-img');
      const prev = document.getElementById('previewContainer');
      prev.innerHTML = '';
      prev.appendChild(img);
    };
    rd.readAsDataURL(file);
  },

  saveUpload() {
    const session = storage.getSession();
    if (!session) return ui.showToast('Please log in first.');
    if (!this.previewDataUrl) return ui.showToast('Choose an image first.');
    const uploads = storage.getUploads(session.username);
    uploads.unshift(this.previewDataUrl); // newest first
    storage.setUploads(session.username, uploads);
    this.previewDataUrl = null;
    document.getElementById('previewContainer').innerHTML = '';
    this.renderMyUploads();
    ui.showToast('Added to My Gallery!');
  },

  renderMyUploads() {
    const session = storage.getSession();
    const myGrid = document.getElementById('myGrid');
    myGrid.innerHTML = '';
    if (!session) return;
    const uploads = storage.getUploads(session.username);
    uploads.forEach(src => myGrid.appendChild(this.imgEl(src)));
  }
};

/***************
 * PROFILE
 ***************/
const profile = {
  setAvatar(e) {
    const session = storage.getSession();
    if (!session) return ui.showToast('Please log in.');
    const file = e.target.files[0];
    if (!file) return;
    const rd = new FileReader();
    rd.onload = () => {
      storage.setAvatar(session.username, rd.result);
      populate.profile();
      ui.showToast('Avatar updated!');
    };
    rd.readAsDataURL(file);
  }
};

const populate = {
  profile() {
    const s = storage.getSession();
    const users = storage.getUsers();
    const u = s ? users[s.username] : null;
    document.getElementById('profUsername').textContent = s ? s.username : '—';
    document.getElementById('profEmail').textContent = u?.email || '—';

    const av = storage.getAvatar(s?.username || '');
    const box = document.getElementById('avatarPreview');
    box.innerHTML = '';
    if (av) {
      const img = document.createElement('img'); img.src = av; box.appendChild(img);
    } else {
      box.textContent = '🧊';
    }
  }
};

/***************
 * NAV / FLOW
 ***************/
function goGallery() {
  const session = storage.getSession();
  if (!session) {
    ui.showToast('Please log in to view the gallery.');
    ui.showPage('auth');
    auth.switchTab('login');
  } else {
    ui.showPage('gallery');
    gallery.init();
  }
}

/***************
 * BOOT
 ***************/
(function init() {
  ui.applyTheme();
  const session = storage.getSession();
  ui.setNavState(!!session);
  populate.profile();
  gallery.init();
})();